% Trefethen, p4.m
% Spectral differentiation on periodic grid
% Compare Differentiation matrix approach with fft

clear all;close all;clc;
N=24; 
h=2*pi/N;
x=h*(1:N)';

%%% Method 1: Interpolant of delta function
C=[0 0.5*(-1).^(1:N-1).*cot((1:N-1)*h/2)]';
D=toeplitz(C,C([1 N:-1:2]));

% Hat function
v=max(0,1-abs(x-pi)/2); clf
subplot(2,2,1)
plot(x,v,'.-','markersize',13);  
axis([0 2*pi -0.5 1.5]), grid on, title('function')
subplot(2,2,2)
plot(x,D*v,'.-','markersize',13);
axis([0 2*pi -1 1]), grid on, title('spectral derivative')

% exp(sin(x))
v=exp(sin(x)); vprime=cos(x).*v;
subplot(2,2,3)
plot(x,v,'.-','markersize',13);
axis([0 2*pi 0 3]), grid on 
subplot(2,2,4)
plot(x,D*v,'.-','markersize',13);
axis([0 2*pi -2 2]), grid on
error=norm(D*v-vprime,inf);
text(2.2,1.4,['max error = ' num2str(error)])

%%% Method 2: FFT
% Hat function
v=max(0,1-abs(x-pi)/2); v_hat=fft(v);
w_hat = 1i*[0:N/2-1 0 -N/2+1:-1]' .* v_hat;
w=real(ifft(w_hat)); 

figure(2)
subplot(2,2,1)
plot(x,v,'.-','markersize',13); 
axis([0 2*pi -0.5 1.5]), grid on, title('function')
subplot(2,2,2)
plot(x,w,'.-','markersize',13);
axis([0 2*pi -1 1]), grid on, title('spectral derivative')

% exp(sin(x))
v=exp(sin(x)); vprime=cos(x).*v;
v_hat=fft(v);
w_hat=1i*[0:N/2-1 0 -N/2+1:-1]' .* v_hat;
w=real(ifft(w_hat));

subplot(2,2,3)
plot(x,v,'.-','markersize',13);
axis([0 2*pi 0 3]), grid on 
subplot(2,2,4)
plot(x,w,'.-','markersize',13);
axis([0 2*pi -2 2]), grid on
error=norm(w-vprime,inf);
text(2.2,1.4,['max error = ' num2str(error)])
