% Spectral differentiation on periodic grid
% Compare analytical with fft on a simple N=4 grid

clear all;close all;clc
N=4;
h=2*pi/N;
x=(h:h:2*pi)';

u=exp(sin(x)); 
uprime=cos(x).*u;

% Method 1: Analytical
% Wavenumber vector
ka=[-N/2+1:-1 0:N/2]';

% DFT
u_hat1=h*u'*[exp(-1i*ka(1)*x) exp(-1i*ka(2)*x) exp(-1i*ka(3)*x) exp(-1i*ka(4)*x)]; 
u_hat1=conj(u_hat1'); % Matlab returns conjugate transpose of complex arrays

% Check
%u_hat1=h*[1i*u(1)-u(2)-1i*u(3)+u(4);
%    u(1)+u(2)+u(3)+u(4);
%    -1i*u(1)-u(2)+1i*u(3)+u(4);
%    -u(1)+u(2)-u(3)+u(4);
%    ];

% Take care of the asymmetry for odd derivatives
ka(N/2)=0;
% DFT of the first derivative
w_hat_a=1i*ka.*u_hat1;
% Inverse DFT
wa=(1/2/pi)*w_hat_a'*[exp(1i*ka*x(1)) exp(1i*ka*x(2)) exp(1i*ka*x(3)) exp(1i*ka*x(4))];
% Check
%wa=(1/2)*[u(2)-u(4) u(3)-u(1) u(4)-u(2) u(1)-u(3)];

% Method 2: Matlab fft (see 'help fft')
% Wavenumber vector in Matlab 
k=[0:N/2-1 0 -N/2+1:-1]';

u_hat=fft(u);
w_hat=1i*k .* u_hat;
w=real(ifft(w_hat)); 

subplot(1,2,1)
plot(x,u,'x-','markersize',13,'linewidth',3);
axis([0 2*pi 0 3]), grid on, set(gca,'fontsize',30); title('function')
subplot(1,2,2)
plot(x,w,'o-',x,wa,'+-','markersize',13,'linewidth',3);
legend('matlab fft','analytical')
axis([0 2*pi -2 2]), grid on, set(gca,'fontsize',30), title('1st derivative')

error=norm(w-uprime,inf);
text(0,-1.5,['max error = ' num2str(error)],'fontsize',30)
